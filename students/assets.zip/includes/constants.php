<?php
  //database constants
  define("DB_SERVER", "localhost");
  define("DB_USER", "depotte1");
  define("DB_PASS", "h05fB*m7G5i");
  define("DB_NAME", "depotte1_depotter");
?>
