<div id="menus">
  <div class="toggle-btn" onclick="toggleSidebar()">
        <span></span>
        <span></span>
        <span></span>
  </div>
  <ul>
   <li><a href=""><span class="fa fa-"></span></a></li>
               <li><a href=""><span class="fa fa-tachometer"></span>Student Dashboard</a></li>
                 <li><a href="cgpa.php"><span class="fa fa-eye"></span>My CGPA</a>
       <li><a href=""><span class="fa fa-graduation-cap"></span>COURSES</a>
             <ul>
             <li><a href="courseRegistration.php"><span class="fa fa-plus"></span>Register Courses</a></li>
             <li><a href="viewRegCourses.php"><span class="fa fa-eye"></span>Registered Courses</a></li>
             <li><a href="delCoursesform.php"><span class="fa fa-trash"></span>Drop course(s)</a></li> 
              
          </ul>
             </li> 
                <li><a href="checkresultform.php"><span class="fa fa-check"></span>Check Result</a></li> 
                   <li><a href=""><span class="fa fa-book"></span>E-LIBRARY</a>
                      <ul>
             <li><a href="../admin/viewbooks.php"><span class="fa fa-eye"></span>View Books</a></li> 
             <li><a href="requestbook.php"><span class="fa fa-list"></span>Request Books</a></li> 
             <li><a href="searchbook.php"><span class="fa fa-search"></span>Search Books</a></li>  
          </ul>
       </li>
             <li><a href="complain.php"><span class="fa fa-envelope"></span>Contact Admin</a></li>    
            <li><a href="deleteAnouncement.php"><span class="fa fa-remove"></span>Delete Anouncement</a></li>
             <li><a href=""><span class="fa fa-"></span></a>
               
             </li>
          <li><a href=""><span class="fa fa-"></span></a>
              
              </li>
               <li><a href=""><span class="fa fa-"></span></a></li>
                <li><a href=""><span class="fa fa-"></span></a></li>
                 <li><a href=""><span class="fa fa-"></span></a></li>
                 <li><a href=""><span class="fa fa-"></span></a></li> 
  </ul>
  </div>
                            
                   <div  id="print">   
                          <div class="container"> 
                            <div class="admincontent">