-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 11, 2021 at 12:41 PM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `depotter`
--

-- --------------------------------------------------------

--
-- Table structure for table `accan`
--

CREATE TABLE `accan` (
  `id` int(20) NOT NULL,
  `email` varchar(30) NOT NULL,
  `pword` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `accan`
--

INSERT INTO `accan` (`id`, `email`, `pword`) VALUES
(1, 'abdulmalik@gmail.com', '12345');

-- --------------------------------------------------------

--
-- Table structure for table `accant`
--

CREATE TABLE `accant` (
  `id` int(30) NOT NULL,
  `fname` varchar(30) NOT NULL,
  `sname` varchar(30) NOT NULL,
  `lname` varchar(30) NOT NULL,
  `gender` varchar(30) NOT NULL,
  `birth` varchar(30) NOT NULL,
  `religion` varchar(30) NOT NULL,
  `email` varchar(30) NOT NULL,
  `adde` varchar(30) NOT NULL,
  `pword` varchar(30) NOT NULL,
  `phone` varchar(30) NOT NULL,
  `filename` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `accant`
--

INSERT INTO `accant` (`id`, `fname`, `sname`, `lname`, `gender`, `birth`, `religion`, `email`, `adde`, `pword`, `phone`, `filename`) VALUES
(2, 'pa', 'pa', 'pa', '1', '07/07/2021', '3', 'malik@gmail.com', 'papa', 'kola', '0819919901', 'com.vectorunit.purple.googlepl'),
(15, 'depotter', 'depotter', 'depotter', 'Female', '08/07/2021', 'Christian', 'alade@gmail.com', 'papa', '123456', '09034563637', '11.jpg'),
(16, 'alaga', 'alaga', 'alaga', 'Male', '22/07/2021', 'Islam', 'alaga@gmail.com', 'koko', 'alaga', '0909777677', ''),
(17, 'abdulmalik', 'depotter', 'kekereboi', 'Male', '05/07/2021', 'Islam', 'you@gmail.com', 'papa', 'you', '09034563637', '15.jpg'),
(18, 'akorex', 'akorex', 'babatunde', 'Male', '06/07/2021', 'Islam', 'akorex@gmail.com', 'olodo', 'akorex', '0909777677', 'passport.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `fname` varchar(100) NOT NULL,
  `sname` varchar(100) NOT NULL,
  `lname` varchar(100) NOT NULL,
  `gender` varchar(100) NOT NULL,
  `birth` varchar(100) NOT NULL,
  `religion` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `adde` varchar(100) NOT NULL,
  `pword` varchar(100) NOT NULL,
  `phone` varchar(100) NOT NULL,
  `filename` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `fname`, `sname`, `lname`, `gender`, `birth`, `religion`, `email`, `adde`, `pword`, `phone`, `filename`) VALUES
(1, 'depotter', 'depotter', 'depotter', 'Male', '13/07/2021', 'Islam', 'depotter@gmail.com', 'ibadan', '1234', '09034563637', 'passport.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `bus`
--

CREATE TABLE `bus` (
  `id` int(11) NOT NULL,
  `fname` varchar(100) NOT NULL,
  `sname` varchar(100) NOT NULL,
  `lname` varchar(100) NOT NULL,
  `gender` varchar(100) NOT NULL,
  `birth` varchar(100) NOT NULL,
  `religion` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `adde` varchar(100) NOT NULL,
  `pword` varchar(100) NOT NULL,
  `phone` varchar(100) NOT NULL,
  `filename` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `bus`
--

INSERT INTO `bus` (`id`, `fname`, `sname`, `lname`, `gender`, `birth`, `religion`, `email`, `adde`, `pword`, `phone`, `filename`) VALUES
(1, 'depotter', 'depotter', 'depotter', 'Male', '13/07/2021', 'Islam', 'malik@gmail.com', 'ibadan', 'kola', '09026354564', 'passport.jpg');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `accan`
--
ALTER TABLE `accan`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `accant`
--
ALTER TABLE `accant`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `bus`
--
ALTER TABLE `bus`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `accan`
--
ALTER TABLE `accan`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `accant`
--
ALTER TABLE `accant`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `bus`
--
ALTER TABLE `bus`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
