





<!doctype html>
<html class="no-js" lang="">


<!-- Mirrored from www.radiustheme.com/demo/html/psdboss/akkhor/akkhor/login.php by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 07 Jul 2021 05:35:23 GMT -->
<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>AKKHOR | Login</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Favicon -->
    <link rel="shortcut icon" type="image/x-icon" href="img/favicon.png">
    <!-- Normalize csss -->
    <link rel="stylesheet" href="csss/normalize.css">
    <!-- Main csss -->
    <link rel="stylesheet" href="csss/main.css">
    <!-- Bootstrap csss -->
    <link rel="stylesheet" href="csss/bootstrap.min.css">
    <!-- Fontawesome csss -->
    <link rel="stylesheet" href="csss/all.min.css">
    <!-- Flaticon csss -->
    <link rel="stylesheet" href="fonts/flaticon.css">
    <!-- Animate csss -->
    <link rel="stylesheet" href="csss/animate.min.css">
    <!-- Custom csss -->
    <link rel="stylesheet" href="style.css">
    <!-- Modernize jsss -->
    <script src="jsss/modernizr-3.6.0.min.js"></script>
</head>

<body>
    <!-- Preloader Start Here -->
    <div id="preloader"></div>
    <!-- Preloader End Here -->
    <!-- Login Page Start Here -->
    <div class="login-page-wrap">
        <div class="login-page-content">
            <div class="login-box">
                <div class="item-logo">
                    <img src="img/logo2.png" alt="logo">
                </div>
                <?php
session_start();
?>
<?php
//if( ($_SESSION['LOGGED']) != "true") {
 //echo "<script> location.href='index.php'  </script>";
 
  // }
   ?>          
            <?php
include"config.php";
if (isset($_POST['submit'])) {
   
        $email=$_POST['email'];
          
        $pword=$_POST['pword'];
    
    
 $sql="SELECT * FROM accant WHERE email ='$email'";
 $result= mysqli_query($db,$sql);
 $row= mysqli_fetch_array($result);
 $count=mysqli_num_rows($result);
 if($count>0){
echo("<h3 style='color: red; font-weight: bolder; text-align: center;'>Bursar with $email email Already Exit</h3>");
   // echo"<h3 style='color: white; font-weight: bolder; text-align: center;'>Name Already Exist</h3>";
 }else{
   $sqlee="INSERT INTO accant(email,pword) VALUES('$email','$pword')";
   //	$_SESSION['message'] = "Address saved"; 
	
 $corr = mysqli_query($db,$sqlee);
echo("<h3 style='color: red; font-weight: bolder; text-align: center;'>Bursar with $email  Has Been Sucessfully  Registerd</h3>");
 
 }
   
    
 }   

 

?>

                <h2>Create Account For Accountant</h2>                
                <form method="POST" class="login-form">
                    <div class="form-group">
                        <label>email</label>
                        <input type="text" placeholder="Enter email" name="email"  required=""class="form-control">
                        <i class="far fa-envelope"></i>
                    </div>
                    <div class="form-group">
                        <label>Password</label>
                        <input type="text" placeholder="Enter password" name="pword" required="" class="form-control">
                        <i class="fas fa-lock"></i>
                    </div>
                    <div class="form-group d-flex align-items-center justify-content-between">
                        <div class="form-check">
                            <input type="checkbox" class="form-check-input" id="remember-me">
                            <label for="remember-me" class="form-check-label">Remember Me</label>
                        </div>
                        <a href="#" class="forgot-btn">Forgot Password?</a>
                    </div>
                    <div class="form-group">
                        <button type="submit" name="submit" class="login-btn">Create</button>
                    </div>
                </form>
                <div class="login-social">
                   
                    
                </div>
            </div>
            <div class="sign-up">Don't have an account ? <a href="#">Signup now!</a></div>
        </div>
    </div>
    <!-- Login Page End Here -->
    <!-- jquery-->
    <script src="jsss/jquery-3.3.1.min.js"></script>
    <!-- Plugins jsss -->
    <script src="jsss/plugins.js"></script>
    <!-- Popper jsss -->
    <script src="jsss/popper.min.js"></script>
    <!-- Bootstrap jsss -->
    <script src="jsss/bootstrap.min.js"></script>
    <!-- Scroll Up jsss -->
    <script src="jsss/jquery.scrollUp.min.js"></script>
    <!-- Custom jsss -->
    <script src="jsss/main.js"></script>

</body>


<!-- Mirrored from www.radiustheme.com/demo/html/psdboss/akkhor/akkhor/login.php by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 07 Jul 2021 05:35:23 GMT -->
</html>