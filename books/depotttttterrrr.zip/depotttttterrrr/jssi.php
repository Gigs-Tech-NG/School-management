    <?php
    	include('config.php');
        //include "update.php";
    	$id=$_GET['id'];
    	$query=mysqli_query($connection,"select * from jss1 where id='$id'");
    	$row=mysqli_fetch_array($query);
    ?>
    
    <!DOCTYPE html>
<html lang="en">
    
<!-- Mirrored from html.designstream.co.in/redial/style1/dark/form-validate.html by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 02 Jun 2021 09:49:01 GMT -->
<head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>The Noble</title>
        <link rel="icon" href="dist/images/logo.jpg" />

        <!--Plugin CSS-->
        <link href="dist/css/plugins.min.css" rel="stylesheet">
        <!--main Css-->
        <link href="dist/css/main.min.css" rel="stylesheet">
    </head>
    <body>
        <!-- header-->
        <div id="header-fix" class="header py-4 py-lg-2 fixed-top">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12 col-lg-3 col-xl-2 align-self-center">
                        <div class="site-logo">
                            <a href="indexb.php"><img src="dist/images/logo.jpg " width="60" height="50" alt="" class="img-fluid" /></a>
                        </div>
                        <div class="navbar-header">
                            <button type="button" id="sidebarCollapse" class="navbar-btn bg-transparent float-right">
                                <i class="glyphicon glyphicon-align-left"></i>
                                <span class="navbar-toggler-icon"></span>
                                <span class="navbar-toggler-icon"></span>
                                <span class="navbar-toggler-icon"></span>
                            </button>
                        </div>
                    </div>
                    <div class="col-12 col-lg-3 align-self-center d-none d-lg-inline-block">
                        <form>
                            
                        </form>
                    </div>
                    <div class="col-12 col-lg-6 col-xl-7 d-none d-lg-inline-block">
                        <nav class="navbar navbar-expand-lg p-0">
                            <ul class="navbar-nav notification ml-auto d-inline-flex">
                                <li class="nav-item dropdown  align-self-center">
                                    <a  class="nav-link p-3" data-toggle="dropdown" aria-expanded="false"><span class="lnr lnr-envelope h4 text-white"></span>
                                        <span class="ring-point">
                                            <span class="ring"></span>
                                        </span>
                                    </a>
                                    
                                </li>
                                
                                <li class="nav-item dropdown user-profile align-self-center">
                                    <a  class="nav-link" data-toggle="dropdown" aria-expanded="false"> 
                                        <span class="float-right pl-3 text-white"><i class="fa fa-angle-down"></i></span>
                                        <div class="media">
                                            <img src="dist/images/author." alt="" class="d-flex mr-3 img-fluid redial-rounded-circle-50" width="45" />
                                            <div class="media-body align-self-center">
                                                <p class="mb-2 text-white text-uppercase font-weight-bold"></p>
                                                
                                            </div>
                                        </div>
                                    </a>
                                    
                                </li>
                            </ul>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
        <!-- End header-->

        <!-- Main-content Top bar-->
        <div class="redial-relative mt-80">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12 col-md-2 align-self-center my-3 my-lg-0">
                        <h6 class="text-uppercase redial-font-weight-700 redial-light mb-0 pl-2">Dashboard</h6>


                                 

                    </div>
                    <div class="col-12 col-md-4 align-self-center">
                        <div class="float-sm-left float-none mb-4 mb-sm-0">
                            <!--ol class="breadcrumb mb-0 bg-transparent redial-light">
                                <li class="breadcrumb-item"><a href="#" class="redial-light">Home</a></li>
                                <li class="breadcrumb-item active">Dashboard </li>


                                       

                            </ol--!>
                        </div>
                    </div>
                    <!--div class="col-12 col-md-6">
                        <div class="clearfix d-none d-md-inline">
                            <div class="float-sm-right float-none">
                                <ul class="list-inline mb-0">
                                    <li class="list-inline-item h4 mb-0 redial-brd-right py-3 px-3 mr-0"><a href="#" class="redial-dark"><span class="lnr lnr-move"></span></a></li>
                                    <li class="list-inline-item h4 mb-0 redial-brd-right py-3 px-3 mr-0"><a href="#" class="redial-dark"><span class="lnr lnr-sync"></span></a></li>
                                    <li class="list-inline-item px-3 mr-0"><small class="font-weight-bold">Language : </small></li>
                                    <li class="list-inline-item mr-0 bg-transparent">
                                        <select class="form-control">
                                            <option>English</option>
                                            <option>French</option>
                                            <option>Russian</option>
                                        </select>
                                    </li>
                                </ul> 
                            </div>
                        </div>
                    </div--!>
                </div>
            </div>
        </div>
        <!-- End Main-content Top bar-->

        <!-- main-content-->
       <!-- <div class="wrapper">
            <nav id="sidebar" class="card redial-border-light px-2 mb-4">
                <div class="sidebar-scrollarea">
                    <ul class="metismenu list-unstyled mb-0" id="menu">
                        <li><a href="index-2.html"><i class="fa fa-dashboard pr-1"></i> Dashboard</a></li>
                        <li>
                            <a class="has-arrow" href="#" data-toggle="collapse" aria-expanded="false"><i class="icofont icofont-shopping-cart pr-1"></i> Ecommerce</a>
                             <ul class="collapse list-unstyled">
                                <li><a href="product.html">Product List</a></li>
                                <li><a href="order-view.html">Order View</a></li>
                                <li><a href="order.html">Order</a></li>
                                <li><a href="order-invoice.html">Invoice</a></li>
                            </ul>
                        </li>
                        <li>
                            <a class="has-arrow" href="#" data-toggle="collapse" aria-expanded="false"><i class="icofont icofont-email pr-1"></i> Mailbox</a>
                            <ul class="collapse list-unstyled">
                                <li><a href="inbox.html">Inbox</a></li>
                                <li><a href="mail-details.html">Mail Email</a></li>
                                <li><a href="mail-compass.html">Mail Compose</a></li>
                            </ul>
                        </li>
                        <li>
                            <a class="has-arrow" href="#" data-toggle="collapse" aria-expanded="false"><i class="icofont icofont-pie pr-1"></i> Chart</a>
                            <ul class="collapse list-unstyled">
                                <li><a href="morris.html">Morris</a></li>
                                <li><a href="c3.html">C3</a></li>
                                <li><a href="chart.html">Chart</a></li>
                            </ul>
                        </li>
                        <li class="active">
                            <a  class="has-arrow" href="#" data-toggle="collapse" aria-expanded="false"><i class="icofont icofont-file pr-1"></i> Form </a>
                            <ul class="collapse list-unstyled">
                                <li><a href="file-dropzone.html">File Dropzone</a></li>
                                <li><a href="form-advance.html">Form Advance</a></li>
                                <li><a href="form-basic.html">Form Basic</a></li>                               
                                <li><a href="form-text-editor.html">Form Text Editor</a></li>
                                <li><a href="form-validate.html">Form Validate</a></li>
                                <li><a href="form-wizard.html">Form Wizard</a></li>
                            </ul>
                        </li>
                        <li>
                            <a class="has-arrow" href="#" data-toggle="collapse" aria-expanded="false"><i class="icofont icofont-monitor pr-1"></i> Other Pages</a>
                            <ul class="collapse list-unstyled">
                                <li><a href="lockscreen.html">Lockscreen</a></li>
                                <li><a href="login.html">login</a></li>
                                <li><a href="register.html">Register</a></li>
                                <li><a href="404.html">404 Page</a></li>
                                <li><a href="blank.html">Blank Page</a></li>
                                <li><a href="gallery.html">Gallery</a></li>
                                <li><a href="pricing.html">pricing</a></li>
                                <li><a href="contact-us.html">Contact us</a></li>
                            </ul>
                        </li>
                        <li><a href="icons.html"><i class="icofont icofont-database pr-1"></i> Icons</a></li>
                        <li>
                            <a class="has-arrow" href="#" data-toggle="collapse" aria-expanded="false"><i class="icofont icofont-ruler-compass pr-1"></i> UI Elements</a>
                            <ul class="collapse list-unstyled">
                                <li><a href="typography.html">Typography</a></li>
                                <li><a href="buttons.html">Buttons</a></li>
                                <li><a href="chat.html">Chat</a></li>
                                <li><a href="alert.html">Alert</a></li>
                                <li><a href="toastr-alert.html">Toastr Alert</a></li>
                                <li><a href="models.html">Models</a></li>
                                <li><a href="accordian.html">Accordian</a></li>
                                <li><a href="sweet-alerts.html">Sweet Alert</a></li>
                                <li><a href="range-slider.html">Range Slider</a></li>
                                <li><a href="progress-bar.html">Progress Bar</a></li>
                                <li><a href="timeline.html">Timeline</a></li>
                                <li><a href="tree-view.html">Tree View</a></li>
                                <li><a href="tabs.html">Tabs</a></li>
                                <li><a href="video.html">Video</a></li>
                            </ul>
                        </li>
                        <li><a href="grid-options.html"><i class="icofont icofont-social-delicious pr-1"></i> Grid options</a></li>
                        <li>
                            <a class="has-arrow" href="#" data-toggle="collapse" aria-expanded="false"><i class="icofont icofont-table pr-1"></i> Tables</a>
                            <ul class="collapse list-unstyled">
                                <li><a href="data-table.html">Data Table</a></li>
                                <li><a href="table-basic.html">Basic Table</a></li>
                                <li><a href="table-editable.html">Table Editable</a></li>
                            </ul>
                        </li>
                        <li>
                            <a class="has-arrow" href="#" data-toggle="collapse" aria-expanded="false"><i class="icofont icofont-ui-user pr-1"></i> User Profile</a>
                            <ul class="collapse list-unstyled">
                                <li><a href="user-list.html">User List</a></li>
                                <li><a href="user-profile.html">User Profile</a></li>
                            </ul>
                        </li>
                        <li>
                            <a class="has-arrow" href="#" data-toggle="collapse" aria-expanded="false"><i class="icofont icofont-location-pin pr-1"></i> Map</a>
                            <ul class="collapse list-unstyled">
                                <li><a href="google-map.html">Google Map</a></li>
                                <li><a href="vector-map.html">Vector Map</a></li>
                            </ul>
                        </li>
                        <li>
                            <a class="has-arrow" href="#" data-toggle="collapse" aria-expanded="false"><i class="icofont icofont-layout pr-1"></i> Blog</a>
                            <ul class="collapse list-unstyled">
                                <li><a href="blog-list.html">Blog List</a></li>
                                <li><a href="blog-post.html">Blog Post</a></li>
                            </ul>
                        </li>
                        <li><a href="calendar.html"><i class="icofont icofont-ui-calendar pr-1"></i> Calendar</a></li>
                    </ul>
                </div>
            </nav>-->

                        
    <div id="content">
                <div class="row">
                    <div class="col-12 col-sm-12">
                        <div class="row mb-4">
                            <div class="col-12 col-sm-12">
                                <div class="card redial-border-light redial-shadow">
                                    <div class="card-body">
                                        <div class="row d-flex justify-content-center">
                                            <div class="col-12 col-sm-10">
                                                <div class="row">
                                                    <div class="col-12 col-sm-6">
                                                    <a href="jss1_fetch.php.php">Back</a>

                                                        <form  data-toggle="validator" method="POST" action="update.php?id=<?php echo $id; ?>">

                                                            <div class="form-group">
                                                                <label class="redial-font-weight-600">Student Name</label> 
                                                                <input type="text" style="border-radius: 10px; border: none; background: #e83e8c;" value="<?php echo $row['name']; ?>"  disabled=""class="form-control" data-error="Name is invalid" name="name" required>
                                                                <div class="help-block with-errors"></div>
                                                            </div>
                                                            
                                                            
                                                        
                                                            <div class="form-group">
                                                                <label class="redial-font-weight-600">Gender</label> 
                                                                <input type="text" style="border-radius: 10px; border: none; background: #e83e8c;" value="<?php echo $row['gender']; ?>"disabled="" class="form-control" data-error="Third name  is invalid" name="gender"required>
                                                                <div class="help-block with-errors"></div>
                                                            </div>
                                                           
                                                            <div class="form-group">
                                                                <label class="redial-font-weight-600">Gender</label> 
                                                                <input type="text" style="border-radius: 10px; border: none;background: #e83e8c;" value="<?php $img = 'image/'.$row['filename'];?>" class="form-control" data-error="Third name  is invalid" name="gender"required>
                                                                <div class="help-block with-errors"></div>
                                                            </div>
                                                           
                                                               <img src="<?php echo $img;?>" alt="" width='100' height='80' style='border-radius:50%;' />
                   
                                                        
                                                        
                                                    </div>
                                                            <div class="form-group">
                                                                
                                                                
                                                               
                                                                </div>
                                                                
                                                         
                                                            <div class="form-group">
                                                                
                                                               
                                                            </div>
                                                        </form>
                                                    </div>
                                                    <div class="col-12 col-sm-12 text-center">
                                                        
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>    
            </div>
        </div>
        <!-- End main-content-->

        <!-- Top To Bottom-->
 <a href="#" class="scrollup text-center redial-bg-primary redial-rounded-circle-50"> 
            <h4 class="text-white mb-0"><i class="icofont icofont-long-arrow-up"></i></h4>
        </a>
        <!-- End Top To Bottom-->

        <!-- Chat-->
        <div id="sidechat">
             <a href="#" class="setting text-center redial-bg-primary d-none d-lg-block"> 
                <h4 class="text-white mb-0"><i class="icofont icofont-gear"></i></h4>
            </a>
            <div class="sidbarchat">
                <ul class="nav nav-tabs border-0 justify-content-lg-center my-3 my-lg-0 flex-column flex-sm-row" role="tablist">
                    <li class="nav-item">
                        <a class="nav-link redial-light border-top-0 border-left-0 border-right-0 active pt-0" id="11-tab" data-toggle="tab" href="#11" role="tab" aria-controls="home" aria-selected="true">Chat</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link redial-light border-top-0 border-left-0 border-right-0 pt-0" id="21-tab" data-toggle="tab" href="#21" role="tab" aria-controls="profile" aria-selected="false">Todo</a>
                    </li>
                    
                </ul>
                <div class="tab-content py-4" id="mysideTabContent">
                    <div class="tab-pane fade show active" id="11" role="tabpanel" aria-labelledby="11-tab">
                        <ul class="nav flex-column" role="tablist">
                                        <li class="nav-item redial-divider px-3">
                                            <a class="nav-link active redial-light" data-toggle="tab" href="#tab1" role="tab" aria-selected="true">
                                                <div class="media d-block d-sm-flex text-center text-sm-left py-3">
                                                    <img class="img-fluid d-md-flex mr-sm-3 redial-rounded-circle-50" src="dist/images/author2.jpg" alt="">
                                                    <div class="media-body align-self-center redial-line-height-1_5 mt-2 mt-sm-0">
                                                        <h6 class="mb-1 redial-font-weight-800">Harry Jones</h6>
                                                        Managing Partner at MDD
                                                    </div>
                                                </div>
                                            </a>
                                        </li>
                                        <li class="nav-item redial-divider px-3">
                                            <a class="nav-link redial-light" data-toggle="tab" href="#tab2" role="tab" aria-selected="false">
                                                <div class="media d-block d-sm-flex text-center text-sm-left py-3">
                                                    <img class="img-fluid d-md-flex mr-sm-3 redial-rounded-circle-50" src="dist/images/author3.jpg" alt="">
                                                    <div class="media-body align-self-center redial-line-height-1_5 mt-2 mt-sm-0">
                                                        <h6 class="mb-1 redial-font-weight-800">Daniel Taylor</h6>
                                                        Freelance Web Developer
                                                    </div>
                                                </div> 
                                            </a>
                                        </li>
                                        <li class="nav-item redial-divider px-3">
                                            <a class="nav-link redial-light" data-toggle="tab" href="#tab3" role="tab" aria-selected="false">
                                                <div class="media d-block d-sm-flex text-center text-sm-left py-3">
                                                    <img class="img-fluid d-md-flex mr-sm-3 redial-rounded-circle-50" src="dist/images/author.jpg" alt="">
                                                    <div class="media-body align-self-center redial-line-height-1_5 mt-2 mt-sm-0">
                                                        <h6 class="mb-1 redial-font-weight-800">Charlotte </h6>
                                                        Co-Founder & CEO at Pi
                                                    </div>
                                                </div> 
                                            </a>
                                        </li>
                                        <li class="nav-item redial-divider px-3">
                                            <a class="nav-link redial-light" data-toggle="tab" href="#tab4" role="tab" aria-selected="false">
                                                <div class="media d-block d-sm-flex text-center text-sm-left py-3">
                                                    <img class="img-fluid d-md-flex mr-sm-3 redial-rounded-circle-50" src="dist/images/author7.jpg" alt="">
                                                    <div class="media-body align-self-center redial-line-height-1_5 mt-2 mt-sm-0">
                                                        <h6 class="mb-1 redial-font-weight-800">Jack Sparrow</h6>
                                                        Managing Partner at MDD
                                                    </div>
                                                </div> 
                                            </a>
                                        </li>
                                        <li class="nav-item redial-divider px-3">
                                            <a class="nav-link redial-light" data-toggle="tab" href="#tab5" role="tab" aria-selected="false">
                                                <div class="media d-block d-sm-flex text-center text-sm-left py-3">
                                                    <img class="img-fluid d-md-flex mr-sm-3 redial-rounded-circle-50" src="dist/images/author6.jpg" alt="">
                                                    <div class="media-body align-self-center redial-line-height-1_5 mt-2 mt-sm-0">
                                                        <h6 class="mb-1 redial-font-weight-800">Bhaumik</h6>
                                                        Managing Partner at MDD
                                                    </div>
                                                </div> 
                                            </a>
                                        </li>
                                        <li class="nav-item px-3">
                                            <a class="nav-link redial-light" data-toggle="tab" href="#tab6" role="tab" aria-selected="false">
                                                <div class="media d-block d-sm-flex text-center text-sm-left py-3">
                                                    <img class="img-fluid d-md-flex mr-sm-3 redial-rounded-circle-50" src="dist/images/author8.jpg" alt="">
                                                    <div class="media-body align-self-center redial-line-height-1_5 mt-2 mt-sm-0">
                                                        <h6 class="mb-1 redial-font-weight-800">Wood Walton</h6>
                                                        Managing Partner at MDD
                                                    </div>
                                                </div> 
                                            </a>
                                        </li>
                                         <li class="nav-item px-3">
                                            <a class="nav-link redial-light" data-toggle="tab" href="#tab6" role="tab" aria-selected="false">
                                                <div class="media d-block d-sm-flex text-center text-sm-left py-3">
                                                    <img class="img-fluid d-md-flex mr-sm-3 redial-rounded-circle-50" src="dist/images/author8.jpg" alt="">
                                                    <div class="media-body align-self-center redial-line-height-1_5 mt-2 mt-sm-0">
                                                        <h6 class="mb-1 redial-font-weight-800">Wood Walton</h6>
                                                        Managing Partner at MDD
                                                    </div>
                                                </div> 
                                            </a>
                                        </li>
                                         <li class="nav-item px-3">
                                            <a class="nav-link redial-light" data-toggle="tab" href="#tab6" role="tab" aria-selected="false">
                                                <div class="media d-block d-sm-flex text-center text-sm-left py-3">
                                                    <img class="img-fluid d-md-flex mr-sm-3 redial-rounded-circle-50" src="dist/images/author8.jpg" alt="">
                                                    <div class="media-body align-self-center redial-line-height-1_5 mt-2 mt-sm-0">
                                                        <h6 class="mb-1 redial-font-weight-800">Wood Walton</h6>
                                                        Managing Partner at MDD
                                                    </div>
                                                </div> 
                                            </a>
                                        </li>
                                         <li class="nav-item px-3">
                                            <a class="nav-link redial-light" data-toggle="tab" href="#tab6" role="tab" aria-selected="false">
                                                <div class="media d-block d-sm-flex text-center text-sm-left py-3">
                                                    <img class="img-fluid d-md-flex mr-sm-3 redial-rounded-circle-50" src="dist/images/author8.jpg" alt="">
                                                    <div class="media-body align-self-center redial-line-height-1_5 mt-2 mt-sm-0">
                                                        <h6 class="mb-1 redial-font-weight-800">Wood Walton</h6>
                                                        Managing Partner at MDD
                                                    </div>
                                                </div> 
                                            </a>
                                        </li>
                                         <li class="nav-item px-3">
                                            <a class="nav-link redial-light" data-toggle="tab" href="#tab6" role="tab" aria-selected="false">
                                                <div class="media d-block d-sm-flex text-center text-sm-left py-3">
                                                    <img class="img-fluid d-md-flex mr-sm-3 redial-rounded-circle-50" src="dist/images/author8.jpg" alt="">
                                                    <div class="media-body align-self-center redial-line-height-1_5 mt-2 mt-sm-0">
                                                        <h6 class="mb-1 redial-font-weight-800">Wood Walton</h6>
                                                        Managing Partner at MDD
                                                    </div>
                                                </div> 
                                            </a>
                                        </li>
                                    </ul>

                    </div>
                    <div class="tab-pane fade" id="21" role="tabpanel" aria-labelledby="21-tab">
                         <ul class="mb-0 list-unstyled inbox">

                                        <li class="border border-top-0 border-left-0 border-right-0">
                                            <a href="#" class="h6">
                                                <div class="form-group mb-0 p-3">
                                                    <input type="checkbox" id="scheckbox12">
                                                    <label for="scheckbox12" class="redial-dark redial-font-weight-600">John Smith</label>
                                                    <small class='float-right text-muted'><i class="fa fa-paperclip pr-1"></i> Aug 10</small>
                                                    <small class="d-block pt-2"><i class="fa fa-star pr-2"></i> No Subject Lorem ipsum dolor sit amet </small>
                                                </div>
                                            </a>
                                        </li>
                                        <li class="border border-top-0 border-left-0 border-right-0">
                                            <a href="#" class="h6">
                                                <div class="form-group mb-0 p-3">
                                                    <input type="checkbox" id="scheckbox13">
                                                    <label for="scheckbox13" class="redial-dark redial-font-weight-600">Lauren Boggs</label>
                                                    <small class='float-right text-muted'> Nov 5</small>
                                                    <small class="d-block pt-2"><i class="fa fa-star pr-2"></i>Invite Lorem ipsum dolor sit amet</small>
                                                </div>
                                            </a>
                                        </li>
                                        <li class="border border-top-0 border-left-0 border-right-0">
                                            <a href="#" class="h6">
                                                <div class="form-group mb-0 p-3">
                                                    <input type="checkbox" id="scheckbox14">
                                                    <label for="scheckbox14" class="redial-dark redial-font-weight-600">Devid Taylor</label>
                                                    <small class='float-right text-muted'><i class="fa fa-paperclip pr-1"></i> Jan 25</small>
                                                    <small class="d-block pt-2"><i class="fa fa-star pr-2"></i>Developemnt  Lorem ipsum dolor sit amet</small>
                                                    
                                                </div>
                                            </a>
                                        </li>
                                        <li class="border border-top-0 border-left-0 border-right-0">
                                            <a href="#" class="h6">
                                                <div class="form-group mb-0 p-3">
                                                    <input type="checkbox" id="sscheckbox12">
                                                    <label for="sscheckbox12" class="redial-dark redial-font-weight-600">John Smith</label>
                                                    <small class='float-right text-muted'><i class="fa fa-paperclip pr-1"></i> Aug 10</small>
                                                    <small class="d-block pt-2"><i class="fa fa-star pr-2"></i> No Subject Lorem ipsum dolor sit amet </small>
                                                </div>
                                            </a>
                                        </li>
                                        <li class="border border-top-0 border-left-0 border-right-0">
                                            <a href="#" class="h6">
                                                <div class="form-group mb-0 p-3">
                                                    <input type="checkbox" id="sscheckbox13">
                                                    <label for="sscheckbox13" class="redial-dark redial-font-weight-600">Lauren Boggs</label>
                                                    <small class='float-right text-muted'> Nov 5</small>
                                                    <small class="d-block pt-2"><i class="fa fa-star pr-2"></i>Invite Lorem ipsum dolor sit amet</small>
                                                </div>
                                            </a>
                                        </li>
                                        <li class="border border-top-0 border-left-0 border-right-0">
                                            <a href="#" class="h6">
                                                <div class="form-group mb-0 p-3">
                                                    <input type="checkbox" id="sscheckbox14">
                                                    <label for="sscheckbox14" class="redial-dark redial-font-weight-600">Devid Taylor</label>
                                                    <small class='float-right text-muted'><i class="fa fa-paperclip pr-1"></i> Jan 25</small>
                                                    <small class="d-block pt-2"><i class="fa fa-star pr-2"></i>Developemnt  Lorem ipsum dolor sit amet</small>
                                                    
                                                </div>
                                            </a>
                                        </li>
                                         <li class="border border-top-0 border-left-0 border-right-0">
                                            <a href="#" class="h6">
                                                <div class="form-group mb-0 p-3">
                                                    <input type="checkbox" id="ccheckbox14">
                                                    <label for="ccheckbox14" class="redial-dark redial-font-weight-600">Devid Taylor</label>
                                                    <small class='float-right text-muted'><i class="fa fa-paperclip pr-1"></i> Jan 25</small>
                                                    <small class="d-block pt-2"><i class="fa fa-star pr-2"></i>Developemnt  Lorem ipsum dolor sit amet</small>
                                                    
                                                </div>
                                            </a>
                                        </li>
                                         <li class="border border-top-0 border-left-0 border-right-0">
                                            <a href="#" class="h6">
                                                <div class="form-group mb-0 p-3">
                                                    <input type="checkbox" id="vcheckbox14">
                                                    <label for="vcheckbox14" class="redial-dark redial-font-weight-600">Devid Taylor</label>
                                                    <small class='float-right text-muted'><i class="fa fa-paperclip pr-1"></i> Jan 25</small>
                                                    <small class="d-block pt-2"><i class="fa fa-star pr-2"></i>Developemnt  Lorem ipsum dolor sit amet</small>
                                                    
                                                </div>
                                            </a>
                                        </li>
                                        
                                    </ul>

                    </div>
                   
                </div>

            </div>
        </div>
        <!-- End Chat-->
        
        <!-- jQuery -->
        <script src="dist/js/plugins.min.js"></script>        
        <script src="dist/js/common.js"></script>
    </body>