
<?php
      //session_start();
      include 'config.php';
if(isset($_POST['submit'])){
  $email = $_POST['email'];
  $pword = $_POST['pword'];
  $query=mysqli_query($db,"SELECT id FROM accant WHERE email = '$email' AND pword = '$pword'");
  $num_rows=mysqli_num_rows($query);
  $row=mysqli_fetch_array($query);
  $_SESSION["id"]=$row['id'];
  $fetch =$row['id'];
  
if ($num_rows>0)
{
     $_SESSION['LOGGED']="true";
echo "$email has succcesfully log in <a href=teacher-details.php?id=$fetch>Click Here To Complete Your Profile Or Log in</a>";

}
else {
    ?>
    <script type="text/javascript">
            alert("wong parameters.");
            window.location = "inde.php";
        </script>

<?php
             }
             }               
?>  

 
     

              