<?php
//if( ($_SESSION['LOGGED']) != "true") {
 //echo "<script> location.href='inde.php'  </script>";
     //  header("location:javascript://history.go(-1)");
  // }
   ?>
  <?php
    	include('config.php');
        //include "update.php";
    	$id=$_GET['id'];
    	$query=mysqli_query($db,"select * from admin where id='$id'");
    	$row=mysqli_fetch_array($query);
    ?>



<!doctype html>
<html class="no-js" lang="">


<!-- Mirrored from www.radiustheme.com/demo/html/psdboss/akkhor/akkhor/add-teacher.php by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 07 Jul 2021 05:35:33 GMT -->
<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title></title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Favicon -->
    <link rel="shortcut icon" type="image/x-icon" href="img/favicon.png">
    <!-- Normalize csss -->
    <link rel="stylesheet" href="csss/normalize.css">
    <!-- Main csss -->
    <link rel="stylesheet" href="csss/main.css">
    <!-- Bootstrap csss -->
    <link rel="stylesheet" href="csss/bootstrap.min.css">
    <!-- Fontawesome csss -->
    <link rel="stylesheet" href="csss/all.min.css">
    <!-- Flaticon csss -->
    <link rel="stylesheet" href="fonts/flaticon.css">
    <!-- Animate csss -->
    <link rel="stylesheet" href="csss/animate.min.css">
    <!-- Select 2 csss -->
    <link rel="stylesheet" href="csss/select2.min.css">
    <!-- Date Picker csss -->
    <link rel="stylesheet" href="csss/datepicker.min.css">
    <!-- Custom csss -->
    <link rel="stylesheet" href="style.css">
    <!-- Modernize jsss -->
    <script src="jsss/modernizr-3.6.0.min.js"></script>
</head>

<body>
    <!-- Preloader Start Here -->
    <div id="preloader"></div>
    <!-- Preloader End Here -->
    <div id="wrapper" class="wrapper bg-ash">
         <!-- Header Menu Area Start Here -->
        <div class="navbar navbar-expand-md header-menu-one bg-light">
            <div class="nav-bar-header-one">
                <div class="header-logo">
                    <a href="student.php">
                        <img src="img/logo.png" alt="logo">
                    </a>
                </div>
                  <div class="toggle-button sidebar-toggle">
                    <button type="button" class="item-link">
                        <span class="btn-icon-wrap">
                            <span></span>
                            <span></span>
                            <span></span>
                        </span>
                    </button>
                </div>
            </div>
            <div class="d-md-none mobile-nav-bar">
               <button class="navbar-toggler pulse-animation" type="button" data-toggle="collapse" data-target="#mobile-navbar" aria-expanded="false">
                    <i class="far fa-arrow-alt-circle-down"></i>
                </button>
                <button type="button" class="navbar-toggler sidebar-toggle-mobile">
                    <i class="fas fa-bars"></i>
                </button>
            </div>
            
        </div>
        <!-- Header Menu Area End Here -->
        <!-- Page Area Start Here -->
        <div class="dashboard-page-one">
            <!-- Sidebar Area Start Here -->
           
            <!-- Sidebar Area End Here -->
            <div class="dashboard-content-one">
                <!-- Breadcubs Area Start Here -->
                <div class="breadcrumbs-area">
                    <h3>Burser</h3>
                    <ul>
                        <li>
                            <a href="#">Home</a>
                        </li>
                        
                    </ul>
                </div>
                <!-- Breadcubs Area End Here -->
                <!-- Add New Teacher Area Start Here -->
                <div class="card height-auto">
                    <div class="card-body">
   
     <?php
     
     
    if($_SERVER["REQUEST_METHOD"]=="POST") {
     $fname=$_POST['fname'];
    $sname =$_POST['sname'];
    $lname=$_POST['lname'];
      $gender=$_POST['gender'];
        $birth=$_POST['birth'];
          $religion=$_POST['religion'];
            $phone=$_POST['phone'];
        
          $adde=$_POST['adde'];
  
    $filename = $_FILES["uploadfile"]["name"];
    $tempname = $_FILES["uploadfile"]["tmp_name"];    
        $folder = "image/".$filename;
  
  
 

  
  
      $query = "UPDATE admin set fname='$fname',sname='$sname',lname='$lname',gender='$gender',birth='$birth',religion='$religion',adde='$adde',phone='$phone',filename='$filename' WHERE id='$id'";
                    $result = mysqli_query($db, $query) or die(mysqli_error($db));
                    
                    if (move_uploaded_file($tempname, $folder)){
           echo" <img src=".$folder." height=200 width=300 />";
             echo"update succesful";
             }
             
          }                  
?>  

                        
                        <form  method="POST" class="new-added-form" enctype="multipart/form-data">
                            <div class="row">
                                <div class="col-xl-3 col-lg-6 col-12 form-group">
                                    <label>First Name *</label>
                                    <input type="text"  name="fname" value="<?php echo $row['fname']; ?>" placeholder="" class="form-control" required="">
                                </div>
                                <div class="col-xl-3 col-lg-6 col-12 form-group">
                                    <label>Second Name *</label>
                                    <input type="text" name="sname" value="<?php echo $row['sname']; ?>" placeholder=""  class="form-control" required="">
                                </div>
                                <div class="col-xl-3 col-lg-6 col-12 form-group">
                                    <label>Last Name *</label>
                                    <input type="text" name="lname" placeholder="" value="<?php echo $row['lname']; ?>"class="form-control" required="">
                                </div>
                                
                                <div class="col-xl-3 col-lg-6 col-12 form-group">
                                    <label>Gender *</label>
                                    <select required="" name="gender"class="select2" value="<?php echo $row['gender']; ?>" >
                                        <option value="">Please Select Gender *</option>
                                        <option value="Male">Male</option>
                                        <option value="Female">Female</option>
                                        <option value="Others">Others</option>
                                    </select>
                                </div>
                                <div class="col-xl-3 col-lg-6 col-12 form-group">
                                    <label>Date Of Birth *</label>
                                    <input type="text" value="<?php echo $row['birth']; ?>" required="" name="birth"placeholder="dd/mm/yyyy" class="form-control air-datepicker">
                                    <i class="far fa-calendar-alt"></i>
                                </div>
                                
                                
                                <div class="col-xl-3 col-lg-6 col-12 form-group">
                                    <label>Religion *</label>
                                    <select value="<?php echo $row['religion']; ?>" name="religion"class="select2" required="">
                                        <option value="">Please Select Religion *</option>
                                        <option value="Islam">Islam</option>
                                        
                                    
                                        <option value="Christian">Christian</option>
                                          <option value="Others">Others</option>
                            
                                    </select>
                                </div>
                               
                                
                                
                                <div class="col-xl-3 col-lg-6 col-12 form-group">
                                    <label>Address</label>
                                    <input type="text" placeholder="" value="<?php echo $row['adde']; ?>" name="adde"class="form-control" required="">
                                </div>
                                
                                <div class="col-xl-3 col-lg-6 col-12 form-group">
                                    <label>Phone Number</label>
                                    <input type="text" placeholder="" name="phone" value="<?php echo $row['phone']; ?>" class="form-control" required="">
                                </div>
                                
                                
                                <div class="col-lg-6 col-12 form-group mg-t-30">
                                    <label class="text-dark-medium">Upload Accountant image</label>
                                    <input type="file" name="uploadfile" value=""/>
                                </div>
                                
                                <div class="col-xl-3 col-lg-6 col-12 form-group">
                                    <label>Sign Up</label>
                                    <input type="submit" placeholder="" value="Sign Up"name="submit" required=""class="form-control">
                                </div>
                                
                            </div>
                            
                        </form>
                    </div>
                </div>
                <!-- Add New Teacher Area End Here -->
                <footer class="footer-wrap-layout1">
                    <div class="copyright">� Copyrights <a href="#">akkhor</a> 2019. All rights reserved. Designed by <a href="#">PsdBosS</a></div>
                </footer>
            </div>
        </div>
        <!-- Page Area End Here -->
    </div>
    <!-- jquery-->
    <script src="jsss/jquery-3.3.1.min.js"></script>
    <!-- Plugins jsss -->
    <script src="jsss/plugins.js"></script>
    <!-- Popper jsss -->
    <script src="jsss/popper.min.js"></script>
    <!-- Bootstrap jsss -->
    <script src="jsss/bootstrap.min.js"></script>
    <!-- Select 2 jsss -->
    <script src="jsss/select2.min.js"></script>
    <!-- Date Picker jsss -->
    <script src="jsss/datepicker.min.js"></script>
    <!-- Smoothscroll jsss -->
    <script src="jsss/jquery.smoothscroll.min.php"></script>
    <!-- Scroll Up jsss -->
    <script src="jsss/jquery.scrollUp.min.js"></script>
    <!-- Custom jsss -->
    <script src="jsss/main.js"></script>

</body>


<!-- Mirrored from www.radiustheme.com/demo/html/psdboss/akkhor/akkhor/add-teacher.php by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 07 Jul 2021 05:35:33 GMT -->
</html>