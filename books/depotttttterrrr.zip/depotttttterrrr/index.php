<!doctype html>
<html>
<body>
<a href="admin.php">Admin Log in</a>
<a href="inded.php">Accountant Log in</a>
<a href="inde.php">Bursar Log in</a>
<a href="students.php">Create Account For Students</a>
<a href="students-login.php">Students log in</a>



</body>

</html>
