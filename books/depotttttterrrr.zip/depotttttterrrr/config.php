 <?php
 
$db=mysqli_connect("localhost","root","","depottter");
if (!$db){
    die (("failed").mysqli_connect_errno());
}
 
 ?>